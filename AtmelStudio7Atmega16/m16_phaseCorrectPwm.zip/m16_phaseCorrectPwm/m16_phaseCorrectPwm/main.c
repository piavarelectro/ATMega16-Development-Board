/*
 * m16_phaseCorrectPwm.c
 *
 * Created: 12/14/2020 10:15:22 AM
 * Author : admin
 */ 

#include <avr/io.h>

int main(void)
{
    /*phase correct PWM mode, Non-inverting,
	1:256 Prescaler*/
	TCCR0=(1<<WGM00)|(1<<COM01)|(1<<CS02);
	/*Set duty cycle to 50%*/
	OCR0=127;
	/*OC0 outputs PWM waveform*/
	DDRB=(1<<3);
	/*Main loop do nothing*/
    while (1) 
    {
    }
}

