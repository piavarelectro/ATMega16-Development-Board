/*
 * shiftLedPortBRight.c
 *
 * Created: 11/25/2020 7:39:14 PM
 * Author : admin
 */ 

#include <avr/io.h>

#define F_CPU 16000000UL
#include <util/delay.h>

int main(void)
{
	unsigned char temp=0x80;
	/*Port B Output*/
	DDRB=0xFF;
	while (1)
	{
		PORTB=temp;
		_delay_ms(100);
		temp>>=1;
		if(temp==0) temp=0x80;
	}
}

