/*
 * timer_0_demon.c
 *
 * Created: 12/7/2020 4:41:58 PM
 * Author : admin
 */ 

#include <avr/io.h>

int main(void)
{
	DDRB=0x01;
	TCCR0=(1<<CS02)|(1<<CS00);
	TIFR|=(1<<TOV0);
	TCNT0=0;
	while(1){
		if (TIFR&(1<<TOV0))
		{
			TIFR|=(1<<TOV0);
			PORTB^=0x01;		
		}
	}
}

