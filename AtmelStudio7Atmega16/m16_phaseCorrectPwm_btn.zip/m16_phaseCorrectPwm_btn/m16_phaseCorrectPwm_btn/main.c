/*
 * m16_phaseCorrectPwm_btn.c
 *
 * Created: 12/14/2020 10:33:50 AM
 * Author : admin
 */ 

#include <avr/io.h>

/*Buttons to change PWM duty cycle*/
#define lower	((PIND&0x04)==0)
#define higher	((PIND&0x08)==0)

int main(void)
{
    /*phase correct PWM mode, Non-inverting,
	1:256 Prescaler*/
	TCCR0=(1<<WGM00)|(1<<COM01)|(1<<CS02);
	/*Zero duty cycle*/
	OCR0=0;
	/*OC0 Pin Output*/
	DDRB=(1<<3);
	/*PD2 and PD3 as input*/
	DDRD&=(1<<2);
	DDRD&=(1<<3);
	/*Turn PD2 and PD3 High*/
	PORTD=(1<<3)|(1<<2);
    while (1) 
    {
		/*Decreasing PWM Duty Cycle*/
		if (lower)
		{
			/*Wait Until PD2 released*/
			while(lower);
			/*Decrease Duty Cycle By 15*/
			if(OCR0>0)	OCR0-=15;
		}
		/*Increasing PWM Duty Cycle*/
		if (higher)
		{
			/*Wait Until PD3 released*/
			while(higher);
			/*Increase Duty Cycle By 15*/
			if(OCR0<250) OCR0+=15;
		}
    }
}

