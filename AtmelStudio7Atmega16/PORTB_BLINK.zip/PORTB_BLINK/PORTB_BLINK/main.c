/*
 * PORTB_BLINK.c
 *
 * Created: 3/1/2024 2:02:58 PM
 * Author : Admin
 */ 

#include <avr/io.h>

#define F_CPU 8000000UL

#include <util/delay.h>

int main(void)
{
    DDRB=0xFF;
    while (1) 
    {
		PORTB=0;
		_delay_ms(1000);
		PORTB=0xFF;
		_delay_ms(1000);
    }
}

