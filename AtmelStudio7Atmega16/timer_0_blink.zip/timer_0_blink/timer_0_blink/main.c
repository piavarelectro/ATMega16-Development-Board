/*
 * timer_0_blink.c
 *
 * Created: 12/8/2020 9:41:37 PM
 * Author : admin
 */ 

#include <avr/io.h>

#define oneSecond 61

int main(void)
{
    unsigned char cnt=0;
	/*PB0 Output*/
	DDRB=0x01;
	/*Select 1:1024 Pre-Scaler*/
    TCCR0=(1<<CS02)|(1<<CS00);
	/*Clear Interrupt Flage Of Timer 0*/
    TIFR|=(1<<TOV0);
	/*Clear Timer/Counter0*/
    TCNT0=0;
    while(1){
		/*Check for interrupt flage*/
	    if (TIFR&(1<<TOV0))
	    {
		    TIFR|=(1<<TOV0);
			cnt++;
	    }
		/*One second is here*/
		if (cnt>=61)
		{
			cnt=0;
			PORTB^=1;
		}
    }
}

