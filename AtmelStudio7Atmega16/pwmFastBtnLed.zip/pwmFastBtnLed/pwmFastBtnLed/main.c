/*
 * pwmFastBtnLed.c
 *
 * Created: 12/12/2020 9:39:16 PM
 * Author : Admin
 */ 

#include <avr/io.h>

/*Buttons To Adjust PWM Duty Cycle*/
#define dutyInc ((PIND&0x08)==0)
#define dutyDec ((PIND&0x04)==0)

int main(void)
{
	/*PD2 Increase Duty Cycle*/
	DDRD&=~(1<<2);
	/*PD3 Decrease Duty Cycle*/
	DDRD&=~(1<<3);
	/*Turn On PD2 and PD3*/
	PORTD=(1<<2)|(1<<3);
	/*Fast PWM, On-Inverting, 1:64 PreScaler*/
	TCCR0=(1<<WGM01)|(1<<WGM00)|(1<<COM01)|(1<<CS01)|(1<<CS00);
	/*OC0 PWM Pin Output*/
	DDRB=(1<<3);
	/*Duty Cycle 0*/
	OCR0=0;
	while (1)
	{
		/*Increase Duty*/
		if (dutyInc)
		{		
			/*Wait Until Release*/
			while(dutyInc);
			/*Increase At  The Unit Of 25*/
			if(OCR0<250) OCR0+=25;
		}
		/*Decrease Duty*/
		if(dutyDec){		
			/*Wait Until Release*/
			while(dutyDec);
			/*Decrease At The Unit Of 25*/
			if(OCR0>0) OCR0-=25;
		}
	}
}

