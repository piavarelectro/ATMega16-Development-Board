/*
 * m16_timer_0_ctc.c
 *
 * Created: 12/15/2020 11:00:35 AM
 * Author : admin
 */ 

#include <avr/io.h>


int main(void)
{
    /*CTC Mode, With 1:256 Prescaler*/
	TCCR0=(1<<WGM01)|(1<<COM00)|(1<<CS02);
	/*Set a preferred value of OCR0*/
	OCR0=50;
	/*OC0/PB3 Square Wave Output*/
	DDRB=(1<<3);
	/*Main Program Loop Stays Here*/
    while (1) 
    {
    }
}

