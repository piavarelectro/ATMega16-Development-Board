/*
 * timerCounter0_CompareOutputMode.c
 *
 * Created: 12/14/2020 10:36:58 PM
 * Author : admin
 */ 

#include <avr/io.h>

int main(void)
{
    /*CTC Mode, Toggle OC0, 1:1024 Prescaler*/
	TCCR0=(1<<COM00)|(1<<CS02)|(1<<CS00);
	/*OC0 Output*/
	DDRB=(1<<3);
    while (1) 
    {
    }
}

