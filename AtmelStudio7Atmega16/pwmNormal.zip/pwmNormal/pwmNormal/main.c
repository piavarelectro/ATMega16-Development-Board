/*
 * pwmNormal.c
 *
 * Created: 12/12/2020 7:27:52 PM
 * Author : Admin
 */ 

#include <avr/io.h>

int main(void)
{
    /*Fast PWM, On-Inverting, 1:1024 PreScaler*/
	TCCR0=(1<<WGM01)|(1<<WGM00)|(1<<COM01)|(1<<CS02)|(1<<CS00);
	/*OC0 PWM Pin Output*/
	DDRB=(1<<3);
	/*Duty Cycle*/
	OCR0=127;
    while (1) 
    {
    }
}

