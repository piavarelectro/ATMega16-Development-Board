/*
 * randomPortB.c
 *
 * Created: 11/25/2020 9:37:24 PM
 * Author : admin
 */ 

#include <avr/io.h>

#define F_CPU 16000000UL
#include <util/delay.h>

int main(void)
{
	/*Port B Output*/
	DDRB=0xFF;
	while (1)
	{
		PORTB=rand();
		_delay_ms(100);
	}
}

