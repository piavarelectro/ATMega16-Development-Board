/*
 * m16_blink.c
 *
 * Created: 10/10/2020 7:39:16 PM
 * Author : Admin
 */ 

#include <avr/io.h>

#define F_CPU 8000000UL
#include <util/delay.h>

int main(void)
{
    //PORTB AS OUTPUT
	DDRB=0xFF;
    while (1) 
    {
		PORTB=0x00;		//Clear PORTB
		_delay_ms(1000);//Wait For 1000 mS
		PORTB=0xFF;		//Set PORTB
		_delay_ms(1000);//Wait For 1000mS
    }
}

