/*
 * portAportB.c
 *
 * Created: 11/12/2020 7:46:41 PM
 * Author : Admin
 */ 

#include <avr/io.h>


int main(void)
{
    
	DDRA=0xFF;	//PA As Output
	DDRB=0x00;	//PB As Input
	PORTB=0xFF;	//Set PORTB High
    while (1) 
    {
		PORTA=PINB;				//Read PINB
		for(int i=0;i<25;i++);	//A Little Delay
    }
}

