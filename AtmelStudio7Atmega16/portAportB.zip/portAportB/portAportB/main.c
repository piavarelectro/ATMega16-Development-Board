/*
 * portAportB.c
 *
 * Created: 11/12/2020 7:46:41 PM
 * Author : Admin
 */ 

#include <avr/io.h>


int main(void)
{
	//Port A Input
	DDRA=0x00;
	//Turn Port A High
	PORTA=0xFF;
	//Port B Output
	DDRB=0xFF;
    while (1) 
    {	
		//Read PINA
		PORTB=PINA;
		//Make A Little Delay
		for(int i=0;i<25;i++);
    }
}

