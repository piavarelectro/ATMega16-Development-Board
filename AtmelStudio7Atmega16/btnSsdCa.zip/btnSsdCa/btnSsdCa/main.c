/*
 * btnSsdCa.c
 *
 * Created: 11/15/2020 8:40:33 PM
 * Author : Admin
 */ 

#include <avr/io.h>

#define F_CPU 16000000UL
#include <util/delay.h>

int main(void)
{
	//7-Segment data table
	unsigned char cAnode[16]={0xC0,0xF9,0xA4,0xB0,0x99,0x92,0x82,0xF8,0x80,0x90,0x88,0x83,0xC6,0xA1,0x86,0x8E};
	//counting parameter
	unsigned char cnt=0;
	//Port C As Output
	DDRC=0xFF;
	//PIND2 As Input
	DDRD&=~(1<<2);
	//Set PIND2 High
	PORTD=(1<<2);
	while (1)
	{
		//Display the 7-Segments Data
		PORTC=cAnode[cnt];
		//Increase the counter
		if ((PIND&0x04)==0)
		{
			_delay_ms(250);
			cnt++;
		}
		if(cnt>15) cnt=0;
	}
}

