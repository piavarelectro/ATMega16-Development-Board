/*
 * sixDigitMuxCc.c
 *
 * Created: 11/26/2020 10:02:59 PM
 * Author : admin
 */ 

#include <avr/io.h>

#define F_CPU 16000000UL
#include <util/delay.h>

#define onTime 1

int main(void)
{
    unsigned char cCathode[10]={0x3F,0x06,0x5B,0x4F,0x66,0x6D,0x7D,0x07,0x7F,0x6F};
    /*Port B drive the segments*/
    DDRB=0xFF;
    /*Port C drive the digits*/
    DDRC=0xFF;
    while (1) 
    {
		PORTC=0x00;
		PORTB=cCathode[0];
		PORTC=(1<<5);
		_delay_ms(onTime);
		
		PORTC=0x00;
		PORTB=cCathode[1];
		PORTC=(1<<6);
		_delay_ms(onTime);
		
		PORTC=0x00;
		PORTB=cCathode[2];
		PORTC=(1<<7);
		_delay_ms(onTime);
		
		PORTC=0x00;
		PORTB=cCathode[5];
		PORTC=(1<<4);
		_delay_ms(onTime);
		
		PORTC=0x00;
		PORTB=cCathode[4];
		PORTC=(1<<3);
		_delay_ms(onTime);
		
		PORTC=0x00;
		PORTB=cCathode[3];
		PORTC=(1<<2);
		_delay_ms(onTime);
    }
}

