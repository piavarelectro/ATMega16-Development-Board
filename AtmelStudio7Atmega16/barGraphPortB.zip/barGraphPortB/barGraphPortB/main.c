/*
 * barGraphPortB.c
 *
 * Created: 11/25/2020 10:49:29 PM
 * Author : admin
 */ 

#include <avr/io.h>

#define F_CPU 16000000UL
#include <util/delay.h>

int main(void)
{
	unsigned char barGraph[9]={0x00,0x01,0x03,0x07,0x0F,0x1F,0x3F,0x7F,0xFF};
	/*Port B Output*/
	DDRB=0xFF;
	while (1)
	{
		for(int i=0;i<9;i++){
			PORTB=barGraph[i];
			_delay_ms(250);
		}
	}
}

