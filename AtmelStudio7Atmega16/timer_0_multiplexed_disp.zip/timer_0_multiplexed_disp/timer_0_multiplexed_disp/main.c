/*
 * timer_0_multiplexed_disp.c
 *
 * Created: 12/9/2020 10:04:30 AM
 * Author : admin
 */ 

#include <avr/io.h>

void driveDisplay(void);
void timerTick(void);

unsigned char oneMillis=0;
unsigned int  oneSecond=0;
unsigned long secondCount=0;

int main(void)
{
    /*Port B drive the segments*/
    DDRB=0xFF;
    /*Port C drive the digits*/
    DDRC=0xFF;
	/*Timer/Counter0 Set to 1:64 Pre-scaler*/
	TCCR0=(1<<CS01)|(1<<CS00);
	/*Clear TOV0 Flag*/
	TIFR=(1<<TOV0);
	/*Clear Timer/Counter0 Register*/
	TCNT0=0;
    while (1) 
    {
		/*Timer Task*/
		timerTick();
		/*Display The Numbers*/
		driveDisplay();
    }
}

void driveDisplay(void){
	unsigned char cCathode[10]={0x3F,0x06,0x5B,0x4F,0x66,0x6D,0x7D,0x07,0x7F,0x6F};
	switch(oneMillis){
		/*100000's digit*/
		case 0:	PORTC=0x00;
				PORTB=cCathode[secondCount/100000];
				PORTC=(1<<5);
				break;
		/*10000's digit*/
		case 2: PORTC=0x00;
				PORTB=cCathode[(secondCount%100000)/10000];
				PORTC=(1<<6);
				break;
		/*1000's digit*/
		case 4:	PORTC=0x00;
				PORTB=cCathode[(secondCount%10000)/1000];
				PORTC=(1<<7);
				break;
		/*100's digit*/		
		case 6:	PORTC=0x00;
				PORTB=cCathode[(secondCount%1000)/100];
				PORTC=(1<<2);
				break;
		/*10's digit*/		
		case 8:	PORTC=0x00;
				PORTB=cCathode[(secondCount%100)/10];
				PORTC=(1<<3);
				break;
		/*1's digit*/		
		case 10:PORTC=0x00;
				PORTB=cCathode[secondCount%10];
				PORTC=(1<<4);
				break;
	}
}

void timerTick(void){
	/*Check the 1ms timer tick*/
	if (TIFR&(1<<TOV0))
	{
		TIFR=(1<<TOV0);
		/*this variable drive all six digits*/
		if(oneMillis>10) oneMillis=0;
		else oneMillis++;	
		oneSecond++;
	}
	/*Check if it's 0.1 second*/
	if (oneSecond>98)
	{
		oneSecond=0;
		secondCount++;
	}
}