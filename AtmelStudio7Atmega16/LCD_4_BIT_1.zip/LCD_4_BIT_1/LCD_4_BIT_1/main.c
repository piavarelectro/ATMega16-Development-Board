/*
 * LCD_4_BIT_1.c
 *
 * Created: 3/1/2024 2:18:26 PM
 * Author : Admin
 */ 

#include <avr/io.h>

#define F_CPU 8000000UL
#include <util/delay.h>

#define LCD_RS	 2
#define LCD_EN	 3
#define LCD_PORT PORTC
#define LCD_DIR	 DDRC

const uint8_t LATCH_TIME=75;

void lcd_command(uint8_t temp){
	uint8_t command = temp&0xF0;
	LCD_PORT=0;
	LCD_PORT=command|(1<<LCD_EN);
	_delay_us(LATCH_TIME);
	LCD_PORT=command;
	_delay_us(LATCH_TIME);
	
	command=temp<<4;
	LCD_PORT=command|(1<<LCD_EN);
	_delay_us(LATCH_TIME);
	LCD_PORT=command;
	_delay_us(LATCH_TIME);
	
}

void lcd_data(uint8_t temp){
	uint8_t data = temp&0xF0;
	LCD_PORT=0;
	LCD_PORT=data|(1<<LCD_EN)|(1<<LCD_RS);
	_delay_us(LATCH_TIME);
	LCD_PORT=data|(1<<LCD_RS);
	_delay_us(LATCH_TIME);
	
	data=temp<<4;
	LCD_PORT=data|(1<<LCD_EN)|(1<<LCD_RS);
	_delay_us(LATCH_TIME);
	LCD_PORT=data|(1<<LCD_RS);
	_delay_us(LATCH_TIME);
	
}

void lcd_text(uint8_t *text){
	while(*text) {lcd_data(*text++); _delay_us(10);}
}

void lcd_xy(uint8_t x, uint8_t y){
	uint8_t cursor[]={0x80,0xC0};
	lcd_command(cursor[y-1]+x-1);
}

void lcd_clear(void){
	lcd_command(0x01);
	_delay_ms(10);	
}

void lcd_init(void){
	LCD_DIR=0xFF;
	LCD_PORT=0x00;
	_delay_us(100);
	lcd_command(0x33);
	_delay_us(100);
	lcd_command(0x32);
	_delay_us(100);
	lcd_command(0x28);
	_delay_us(100);
	lcd_command(0x0F);
	_delay_us(100);
	lcd_command(0x01);
	_delay_ms(10);
	lcd_command(0x06);
	_delay_ms(100);
}

int main(void)
{
	_delay_ms(500);
	lcd_init();  
	lcd_xy(1,1);
	lcd_text("HELLO WORLD!");
	lcd_xy(1,2);
	lcd_text("ATMega16 AVR");
	
	_delay_ms(2500);
	lcd_clear();
	
	lcd_text("Microchip Studio");
	lcd_xy(1,2);
	lcd_text("Programming in C");
	
    while (1) 
    {
    }
}

